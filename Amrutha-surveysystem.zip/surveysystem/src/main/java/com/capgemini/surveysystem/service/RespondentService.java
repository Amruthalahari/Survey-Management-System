package com.capgemini.surveysystem.service;

/*
 * This method is used to call respondentlogin method
 */
public interface RespondentService {
	public boolean choiceVerify(String choice);

	public boolean userNameVerify(String userName);

	public boolean passwordVerify(String password);

	public boolean surveyVerify(String survey);

	public boolean multipleAnswerVerify(String answer);

	public boolean phoneNoVerify(String phonenum);

	public boolean answerVerify(String answer);

	public boolean answerVerify1(String answer);

	public boolean respondentLogin(String userName, String password);

	public boolean addAnswers(String s, String answer1, String answer2, String answer3, String answer4);
	
	public boolean addRespondent(String userName,String password);

	public boolean viewResponse();

}