package com.capgemini.surveysystem.dao;
/**
 * 
 * @param username argument for method validateAdmin
 * @param password argument for method validateAdmin
 * @return
 */
public interface AdminDao {

	public boolean adminLogin(String adminuserName, String adminPassword);
}
