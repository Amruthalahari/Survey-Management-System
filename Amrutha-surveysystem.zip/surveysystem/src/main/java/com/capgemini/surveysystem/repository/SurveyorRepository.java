package com.capgemini.surveysystem.repository;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveysystem.bean.Surveyor;
import com.capgemini.surveysystem.factory.Factory;
/*
 * This SurveyorRepository consists of dummydata which is used to  login to the Surveyor
 */
public class SurveyorRepository {
	public static List<Surveyor> surveylist = new ArrayList<Surveyor>();
	public List<Surveyor> surveyor(){
		Surveyor surveyorBean1 = Factory.getSurveyorInstance();
		surveyorBean1.setuserName("surveyor");
		surveyorBean1.setPassword("surveyor");
		surveylist.add(surveyorBean1);
		return surveylist;

}
}