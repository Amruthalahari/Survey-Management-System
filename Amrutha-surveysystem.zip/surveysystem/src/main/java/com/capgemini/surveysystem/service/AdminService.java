package com.capgemini.surveysystem.service;
import java.util.Scanner;

import com.capgemini.surveysystem.bean.Admin;
import com.capgemini.surveysystem.factory.Factory;
/**
 * @param adminservice 
 * @return true(login successful)
 */


public interface AdminService {
	Scanner sc = new Scanner(System.in);
	
	Admin adminbean= Factory.getAdminInstance();
	
	public boolean Login(String adminuserName, String adminPassword) ;

	public boolean choiceValidation(String choice);
}
