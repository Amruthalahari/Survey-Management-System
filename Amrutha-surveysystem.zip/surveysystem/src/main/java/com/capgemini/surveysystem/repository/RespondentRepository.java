package com.capgemini.surveysystem.repository;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveysystem.bean.Respondent;
import com.capgemini.surveysystem.factory.Factory;
/*
 * This RespondRepository consists of dummydata which is used to  login to the Respondent
 */
public class RespondentRepository {
	public static ArrayList<Respondent> respondentlist = new ArrayList<Respondent>();
	public List<Respondent> respondent() {
		Respondent respondentBean1 = Factory.getRespondentInstance();
		respondentBean1.setuserName("respondent");
		respondentBean1.setPassword("respondent");
		respondentlist.add(respondentBean1);
		Respondent respondentBean2 = Factory.getRespondentInstance();
		respondentBean2.setuserName("lahari");
		respondentBean2.setPassword("lahari3");
		respondentlist.add(respondentBean2);
		return respondentlist;

	}
}