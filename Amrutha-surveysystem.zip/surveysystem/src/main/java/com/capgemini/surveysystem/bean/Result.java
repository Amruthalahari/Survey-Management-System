package com.capgemini.surveysystem.bean;
import java.io.Serializable;
/**
 * This is belongs to Surveyor to give answers to the survey;
 *
 */
public class Result implements Serializable{
	private static final long serialVersionUID = 1L;

	public Result() {
		
	}
private String answer1, answer2, answer3, answer4,survey;

	public String getSurvey() {
		return survey;
	}

	public void setSurvey(String survey) {
		this.survey = survey;
	}

	public String getAnswer1() {
		return answer1;
	}

	public void setAnswer1(String answer1) {
		this.answer1 = answer1;
	}

	public String getAnswer2() {
		return answer2;
	}

	public void setAnswer2(String answer2) {
		this.answer2 = answer2;
	}

	public String getAnswer3() {
		return answer3;
	}

	public void setAnswer3(String answer3) {
		this.answer3 = answer3;
	}

	public String getAnswer4() {
		return answer4;
	}

	public void setAnswer4(String answer4) {
		this.answer4 = answer4;
	}

	
	@Override
	public String toString() {
		return "ResultBean [answer1=" + answer1 + ", answer2=" + answer2 + ", answer3=" + answer3 + ", answer4="
				+ answer4 + ", survey=" + survey + "]";
	}

}