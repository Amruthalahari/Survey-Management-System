package com.capgemini.surveysystem.dao;
import java.util.Iterator;
import com.capgemini.surveysystem.bean.Respondent;
import com.capgemini.surveysystem.bean.Result;
import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.service.RespondentServiceImpl;
import com.capgemini.surveysystem.validation.InputValidation;

public class RespondentDaoImpl implements RespondentDao {
	InputValidation inputValidation = Factory.getInputValidationInstance();
	Survey surveyBean = Factory.getSurveyInstance();
	Result resultBean = Factory.getResultInstance();
	
	@Override
	public boolean respondentLogin(String userName, String password) {
		int count = 0;
		Iterator<Respondent> respondentBean3 = RespondentRepository.respondentlist.iterator();
		while (respondentBean3.hasNext()) {
			Respondent repondent = respondentBean3.next();
			if (repondent.getuserName().contentEquals(userName)
					&& repondent.getPassword().contentEquals(password)) {
				count++;
			}
		}
		if (count == 0) {
			return false;
		}  else {
			return true;
		}
		
		}
	
	@Override
	public boolean responseView() {
		if (RespondentServiceImpl.respondentSurvey.isEmpty()) {
			return true;
		} else {
			return false;
		}

		
	}

	@Override
	public boolean addRespondent(Respondent respondent) {
		 RespondentRepository.respondentlist.add(respondent);
		return true;
	}
}
