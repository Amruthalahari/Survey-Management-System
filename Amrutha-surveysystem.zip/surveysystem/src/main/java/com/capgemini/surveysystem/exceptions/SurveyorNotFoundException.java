package com.capgemini.surveysystem.exceptions;
@SuppressWarnings("serial")
public class SurveyorNotFoundException extends RuntimeException{
	String message="Survery  not found";
public SurveyorNotFoundException() {
		
	}
	public SurveyorNotFoundException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}


}
