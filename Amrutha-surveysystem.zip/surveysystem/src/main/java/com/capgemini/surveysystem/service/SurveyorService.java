package com.capgemini.surveysystem.service;

public interface SurveyorService {

	public boolean choiceVerify(String choice);

	public boolean descriptionVerify(String description);

	public boolean questionVerify(String question);

	public boolean surveyVerify(String survey);
	
	public boolean nameVerify(String name);

	public boolean checkSurvey(String newsurvey);

	public boolean update(String survey);

	public boolean createSurvey(String survey, String description, String q1, String q2,String q3, String q4);

	public boolean Login(String surveyoruserName, String surveyorPassword);

	public boolean surveyView();
	
	public boolean addSurveyor(String userName,String password,String gmail,Long mobileNumber);

}
