package com.capgemini.surveysystem.repository;
import java.util.ArrayList;
import java.util.List;

import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.factory.Factory;

public class SurveyRepository {
	public static List<Survey> surveyNames = new ArrayList<Survey>();

	public static List<Survey> survey() {
		Survey surveybean1 = Factory.getSurveyInstance();
		surveybean1.setSurveyName("flipcart");
		surveybean1.setDescription("app");
		surveybean1.setQuestion1("Select the item you want?");
		surveybean1.setQuestion2("Enter the colour?");
		surveybean1.setQuestion3("Enter the size?");
		surveybean1.setQuestion4("Enter the paymentmethod?");
		surveyNames.add(surveybean1);
		Survey surveybean2 = Factory.getSurveyInstance();
		surveybean2.setSurveyName("amazon");
		surveybean2.setDescription("app");
		surveybean2.setQuestion1("Select the item you want?");
		surveybean2.setQuestion2("Enter the colour?");
		surveybean2.setQuestion3("Enter the size?");
		surveybean2.setQuestion4("Enter the paymentmethod?");
		surveyNames.add(surveybean2);
		return surveyNames;

	}
}
