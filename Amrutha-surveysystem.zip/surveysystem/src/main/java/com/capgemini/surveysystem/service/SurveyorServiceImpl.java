package com.capgemini.surveysystem.service;
import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.bean.Surveyor;
import com.capgemini.surveysystem.dao.SurveyorDao;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.validation.InputValidation;

public class SurveyorServiceImpl implements SurveyorService {
	InputValidation inputValidation = Factory.getInputValidationInstance();
	Survey surveyBean = Factory.getSurveyInstance();
	SurveyorDao surveyorDao =Factory.getSurveyorDaoInstance();

	@Override
	public boolean choiceVerify(String choice) {
		while (!inputValidation.choiceValidation(choice)){

			return false;
		}
		return true;

	}

	@Override
	public boolean descriptionVerify(String description) {
		while(!inputValidation.descriptionValidation(description)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean questionVerify(String question) {
		while(!inputValidation.questionValidation(question)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean surveyVerify(String survey) {
		while(!inputValidation.surveyValidation(survey)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean nameVerify(String name) {
		while(!inputValidation.nameValidation(name)) {
			return false;
		}
		return true;
	}
	
	@Override
	public boolean Login(String surveyorUserName, String surveyorPassword) {
		boolean Login= surveyorDao.login(surveyorUserName, surveyorPassword);
		if(Login==true) {
			return true;
		}
		return false;
	}

	@Override
	public boolean checkSurvey(String survey1) {
		return surveyorDao.deleteSurvey(survey1);
		
	}
	@Override
	public boolean update(String survey) {
		return surveyorDao.updateSurvey(survey);
	}



	@Override
	public boolean createSurvey(String survey, String description, String q1, String q2,String q3, String q4) {
		surveyBean.setSurveyName(survey);
		surveyBean.setDescription(description);
		surveyBean.setQuestion1(q1);
		surveyBean.setQuestion2(q2);
		surveyBean.setQuestion3(q3);
		surveyBean.setQuestion4(q4);
		
		SurveyRepository.surveyNames.add(surveyBean);
		return false;
	}

	@Override
	public boolean surveyView() {
		return surveyorDao.viewSurvey();
	}

	@Override
	public boolean addSurveyor(String userName, String password,String gmail,Long mobileNumber) {
		Surveyor surveyor = Factory.getSurveyorInstance();
		surveyor.setuserName(userName);
		surveyor.setPassword(password);
		surveyor.setEmailId(gmail);
		surveyor.setPhoneNo(mobileNumber);
		return surveyorDao.addSurveyor(surveyor);
	}
	}
