package com.capgemini.surveysystem.dao;
/**
 * This is Respondent inteface and we declare methods
 *   and here we write methods to login torespondent, add respondent and to view the response
 */

import com.capgemini.surveysystem.bean.Respondent;

public interface RespondentDao {

	public boolean respondentLogin(String userName, String password);
	public boolean responseView();
	public boolean addRespondent(Respondent respondent);

}