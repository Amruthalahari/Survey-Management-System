package com.capgemini.surveysystem.controller;

import java.util.List;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.controller.RespondentController;
import com.capgemini.surveysystem.controller.SurveyController;
import com.capgemini.surveysystem.bean.Respondent;
import com.capgemini.surveysystem.bean.Result;
import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.exceptions.InvalidSurveyNameException;
import com.capgemini.surveysystem.exceptions.RespondentException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.service.RespondentService;
import com.capgemini.surveysystem.service.RespondentServiceImpl;
import com.capgemini.surveysystem.validation.InputValidation;;

/*
 * This is the Respondent controller in which Respondent can be able to give response to the survey
 *  and can view the response
 */
public class RespondentController {
	static final Logger log = Logger.getLogger(SurveyController.class);
	static InputValidation inputValidation = Factory.getInputValidationInstance();
	static Respondent respondentBean = Factory.getRespondentInstance();
	static RespondentService respondentService = Factory.getRespondentServiceInstance();
	static Survey surveyBean = Factory.getSurveyInstance();
	static Result resultBean = Factory.getResultInstance();

	static Scanner sc = new Scanner(System.in);
	static int count=0;
	public static void respondentLogin() {
		log.info(" Please enter the Respondent userName(a-z)");
		String userName = sc.next();
		respondentService.userNameVerify(userName);
		while (!respondentService.userNameVerify(userName)) {
			log.info("please enter  the valid username");
			userName = sc.next();
		}

		log.info("Please enter your password (a-z)");
		String password = sc.next();
		respondentService.passwordVerify(password);
		while (!respondentService.passwordVerify(password)) {
			log.info("please enter the  valid password");
			password = sc.next();
		}

	  A:try {
			if (respondentService.respondentLogin(userName, password)) {
				log.info("login successful");
				log.info("Available surveys are :flipcart,amazon ");
				log.info("enter the survey name (a-z)");
				String survey2 = sc.next();
                    for(Survey survey : SurveyRepository.survey()) {
					if (survey.getSurveyName().contentEquals(survey2)) {
						count++;
						// sc.nextLine();
						String s = survey.getSurveyName();
						log.info(survey.getQuestion1());

						log.info(" Please answer question1 (a-zA-Z)");
						String answer1 = sc.next();
						// sc.nextLine();
						while (!respondentService.answerVerify(answer1)) {
							log.info("please enter the valid answer");
							answer1 = sc.nextLine();
						}
						log.info(survey.getQuestion2());
						log.info(" Please answer question2 (a-zA-Z)");
						String answer2 = sc.next();
						while (!respondentService.answerVerify(answer2)) {
							log.info("please enter the valid answer");
							answer2 = sc.nextLine();
						}
						log.info(survey.getQuestion3());

						log.info(" Please answer question3 (a-zA-Z)");
						String answer3 = sc.next();
						while (!respondentService.answerVerify1(answer3)) {
							log.info("please enter the valid answer");
							answer3 = sc.nextLine();
						}

						log.info(survey.getQuestion4());
						log.info(" Please answer question 4(a-zA-Z)");
						String answer4 = sc.next();
						while (!respondentService.answerVerify1(answer4)) {
							log.info("please enter valid answer");
							answer4 = sc.nextLine();
						}

						respondentService.addAnswers(s, answer1, answer2, answer3, answer4);

						log.info("Thank you for the Response\n");

						do {
							log.info("select an option(1-2)");
							log.info("1.view response");
							log.info("2.Exit");

							String choice = sc.next();
							while (!respondentService.choiceVerify(choice)) {
								log.info("please enter the valid choice");
								choice = sc.next();
							}
							int choice1 = Integer.parseInt(choice);

							switch (choice1) {

							case 1:
								respondview();
								break;

							case 2:
								break A;
							default:
								log.info("Choose the correct choice");
								break;
							}

						} while (true);
					}
                    }try {
    					if (count == 0) {
    						throw new InvalidSurveyNameException();
    					}
    				} catch (InvalidSurveyNameException e) {
    					log.error(e.getMessage());
    				}
					}else {
				throw new RespondentException();
			}
		} catch (RespondentException e) {
			log.info(e.getMessage());
		}
	}
	

	public static List<Result> respondview() {
		boolean viewAnswers = respondentService.viewResponse();
		for (@SuppressWarnings("unused") Result resultBean : RespondentServiceImpl.respondentSurvey) {
			if (viewAnswers == true) {
				log.info("There is no response to view");
			} else {
				// log.info(resultBean);
				for (Result result : RespondentServiceImpl.respondentSurvey) {
					log.info(result + "\n");
				}
			}

		}
		return RespondentServiceImpl.respondentSurvey;
	}

	public static void addRespondent() {
		log.info("please enter the required credintials to create account");
		log.info(" Please enter new Respondent userName(a-z)");
		String userName = sc.next();
		while (!respondentService.userNameVerify(userName)) {
			log.info("please enter  the valid username");
			userName = sc.next();
		}

		log.info("Please enter new password (a-z)");
		String password = sc.next();
		while (!respondentService.passwordVerify(password)) {
			log.info("please enter the  valid password");
			password = sc.next();
		}
		log.info("Your response is added successfully\n");
		respondentService.addRespondent(userName, password);

	}
}