package com.capgemini.surveysystem.exceptions;
@SuppressWarnings("serial")
public class RespondentException extends RuntimeException{
	String message="Respondent  not found";
public RespondentException() {
	}
	public RespondentException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}
}
