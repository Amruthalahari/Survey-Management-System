package com.capgemini.surveysystem.validation;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
/**
 * All input validations with regular expressions
 *
 */
public class InputValidationImpl implements InputValidation {
	Pattern pat = null;
	Matcher mat = null;

	public boolean nameValidation(String name) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(name);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean choiceValidation(String choice) {
		pat = Pattern.compile("[1-9&&[^a-zA-Z]]{1}");
		mat = pat.matcher(choice);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean emailValidation(String email) {
		pat = Pattern.compile("^(.+)@(.+)$");
		mat = pat.matcher(email);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean passwordValidation(String passCode) {
		pat = Pattern.compile("[a-zA-Z0-9@!#$%^&*]+");
		mat = pat.matcher(passCode);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean mobileNoValidation(String phoneNo) {
		pat = Pattern.compile("[6-9][0-9]{9}");
		mat = pat.matcher(phoneNo);
		if (mat.matches()) {
			return true;

		}
		return false;
	}

	public boolean surveyValidation(String survey) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(survey);
		if (mat.matches()) {
			return true;

		}
		return false;
	}

	public boolean descriptionValidation(String description) {
		pat = Pattern.compile("(\\p{Lower}+\\s?)");
		mat = pat.matcher(description);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	
	public boolean answerValidation(String answer) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*{10,250}");
		mat = pat.matcher(answer);
		if (mat.matches()) {
			return true;
		}
		return false;
	}


	public boolean multipleAnswerValidation(String answer) {
			pat = Pattern.compile("[a-d]{1}");
			mat = pat.matcher(answer);
			if (mat.matches()) {
				return true;
			}
		return false;
	}

	public boolean answerValidation1(String answer) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*{10,200}");
		mat = pat.matcher(answer);
		if (mat.matches()) {
			return true;
		}
		return false;
	}

	public boolean questionValidation(String question) {
		pat = Pattern.compile("[a-zA-Z\\s]+[\\s[[a-zA-Z]+]]*{5,200}");
		mat = pat.matcher(question);
		if (mat.matches()) {
			return true;
		}
		return false;
	}
}