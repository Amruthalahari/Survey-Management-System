package com.capgemini.surveysystem.bean;
import java.io.Serializable;
/**
 * This is belongs to Respondent login credentials using username and pasword;
 *
 */
public class Respondent implements Serializable{
	private static final long serialVersionUID = 1L;
	public Respondent() {
		
	}
	private String userName;
	private String password;
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Respondent [userName=" + userName + ", password=" + password + ", getuserName()=" + getuserName()
				+ ", getPassword()=" + getPassword() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
				+ ", toString()=" + super.toString() + "]";
	}
	

}
