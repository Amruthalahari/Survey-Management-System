package com.capgemini.surveysystem.factory;
import com.capgemini.surveysystem.bean.Admin;
import com.capgemini.surveysystem.bean.Respondent;
import com.capgemini.surveysystem.bean.Result;
import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.bean.Surveyor;
import com.capgemini.surveysystem.dao.AdminDao;
import com.capgemini.surveysystem.dao.AdminDaoImpl;
import com.capgemini.surveysystem.dao.RespondentDao;
import com.capgemini.surveysystem.dao.RespondentDaoImpl;
import com.capgemini.surveysystem.dao.SurveyorDao;
import com.capgemini.surveysystem.dao.SurveyorDaoImpl;
import com.capgemini.surveysystem.repository.AdminRepository;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.repository.SurveyorRepository;
import com.capgemini.surveysystem.service.AdminService;
import com.capgemini.surveysystem.service.AdminServiceImpl;
import com.capgemini.surveysystem.service.SurveyorService;
import com.capgemini.surveysystem.service.RespondentService;
import com.capgemini.surveysystem.service.RespondentServiceImpl;
import com.capgemini.surveysystem.service.SurveyorServiceImpl;
import com.capgemini.surveysystem.validation.InputValidationImpl;
import com.capgemini.surveysystem.validation.InputValidation;

/*
 * This method is to create the objects for Survey Management System
 */
public class Factory {
	
 public static Surveyor getSurveyorInstance() {
	Surveyor surveyorbean=new Surveyor();
	return surveyorbean;
 }
 public static SurveyorDao getSurveyorDaoInstance(){
	 SurveyorDao surveyorDao = new SurveyorDaoImpl();
	 return surveyorDao;
	 
 }
 public static  SurveyorService getSurveyorServiceInstance() {
	 SurveyorService surveyorService = new SurveyorServiceImpl();
	 return surveyorService;
 }
 public static Admin getAdminInstance() {
	 Admin adminBean = new  Admin();
	 return adminBean;
	 
 }
 public static AdminDao getAdminDaoInstance() {
	 AdminDao adminDao = new AdminDaoImpl();
	 return adminDao;
 }
 public static  AdminService  getAdminServiceInstance() {
	 AdminService adminService =new AdminServiceImpl();
	 return adminService;
 }
 public static Respondent  getRespondentInstance() {
	 Respondent respondentbean = new Respondent();
	 return respondentbean;
 }
 public static RespondentDao getRespondentDaoInstance() {
	RespondentDao respondentDao=new RespondentDaoImpl();
	return respondentDao; 
 }
 public static RespondentService getRespondentServiceInstance() {
	 RespondentService respondentService = new RespondentServiceImpl();
	 return respondentService;
 }
 
 public static Survey getSurveyInstance() {
	 Survey surveybean = new Survey();
	 return surveybean;
 }

 public static Result getResultInstance() {
	 Result resultbean =new Result();
	return resultbean;
	 
 }
 
 public static InputValidation getInputValidationInstance() {
	 return new InputValidationImpl();
 }

 public static SurveyRepository getSurveyRepository() {
	 SurveyRepository surveyrespoRepository = new SurveyRepository();
	 return surveyrespoRepository; 
	 
 }
 public static RespondentRepository getRespondentRepository() {
	 RespondentRepository respondentRespository = new RespondentRepository();
	return respondentRespository;
	 
 }
 public static AdminRepository getAdminRepository() {
	 AdminRepository adminRepository= new AdminRepository();
	return adminRepository;
	 
 }
 public static SurveyorRepository getSurveyorRepository() {
	 SurveyorRepository surveyorRespository= new SurveyorRepository();
	 return surveyorRespository;
 }
 
}
