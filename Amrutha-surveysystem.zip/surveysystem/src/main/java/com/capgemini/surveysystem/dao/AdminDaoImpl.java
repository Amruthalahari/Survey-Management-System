package com.capgemini.surveysystem.dao;


public class AdminDaoImpl implements AdminDao {

	@Override
	public boolean adminLogin(String adminUserName, String adminPassword) {
		if (adminUserName.contentEquals("admin") && adminPassword.equals("admin")) {
			return true;
		}
		return false;
	}
	}



