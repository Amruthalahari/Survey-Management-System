package com.capgemini.surveysystem.service;
import com.capgemini.surveysystem.dao.AdminDao;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.validation.InputValidation;

public class AdminServiceImpl implements AdminService {
	InputValidation inputValidation = Factory.getInputValidationInstance();
	AdminDao adminDao=Factory.getAdminDaoInstance();

	@Override
	public boolean Login(String adminUserName, String adminPassword) {
	 boolean Login =adminDao.adminLogin(adminUserName, adminPassword) ;
		if(Login==true) {
			return true;
		}
		return false;
	}

	@Override
	public boolean choiceValidation(String choice) {
		while (!inputValidation.choiceValidation(choice)){

			return false;
		}
		return true;


}
}
