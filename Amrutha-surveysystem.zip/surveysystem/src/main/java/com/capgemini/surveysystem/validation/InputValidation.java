package com.capgemini.surveysystem.validation;


public interface InputValidation {
	
	public boolean nameValidation(String name);
	
	public boolean choiceValidation(String choice);

	public boolean emailValidation(String email);

	public boolean passwordValidation(String passCode);
	
	public boolean mobileNoValidation(String phoneNo);
	
	public boolean surveyValidation(String survey);
	
	public boolean descriptionValidation(String description);
	
	public boolean questionValidation(String question);
	
	public boolean multipleAnswerValidation(String answer);
	
	public boolean answerValidation(String answer);
	
	public boolean answerValidation1(String answer);
	

}

