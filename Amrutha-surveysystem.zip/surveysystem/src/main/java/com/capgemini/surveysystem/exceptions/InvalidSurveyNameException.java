package com.capgemini.surveysystem.exceptions;
@SuppressWarnings("serial")
public class InvalidSurveyNameException  extends RuntimeException{
	String message="survey not found";
public InvalidSurveyNameException() {
		
	}
	public InvalidSurveyNameException(String message) {
		super();
		this.message = message;
	}
	public String getMessage() {
		return message;	
	}



}
