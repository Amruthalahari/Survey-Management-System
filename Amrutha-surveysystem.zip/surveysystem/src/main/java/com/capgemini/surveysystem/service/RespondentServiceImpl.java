package com.capgemini.surveysystem.service;
import java.util.ArrayList;

import com.capgemini.surveysystem.bean.Respondent;
import com.capgemini.surveysystem.bean.Result;
import com.capgemini.surveysystem.dao.RespondentDao;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.validation.InputValidation;

public class RespondentServiceImpl implements RespondentService {
	InputValidation inputValidation = Factory.getInputValidationInstance();
	RespondentDao respondentDao = Factory.getRespondentDaoInstance();
	Result resultBean = Factory.getResultInstance();
	public static ArrayList<Result> respondentSurvey = new ArrayList<>();
	
	RespondentDao dao= Factory.getRespondentDaoInstance();

	@Override
	public boolean userNameVerify(String userName) {
		if(userName!=null) {
			return inputValidation.nameValidation(userName); 
		}
		
		return false;
	}

	@Override
	public boolean passwordVerify(String password) {
		while (!inputValidation.passwordValidation(password)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean surveyVerify(String survey) {
		while (!inputValidation.surveyValidation(survey)) {
			return false;
		}

		return true;
	}

	@Override
	public boolean multipleAnswerVerify(String answer) {
		while (!inputValidation.multipleAnswerValidation(answer)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean answerVerify(String answer) {
		while (!inputValidation.answerValidation(answer)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean answerVerify1(String answer) {
		while (!inputValidation.answerValidation1(answer)) {
			return false;
		}
		return true;
	}

	@Override
	public boolean phoneNoVerify(String phonenum) {
		while (!inputValidation.mobileNoValidation(phonenum)) {
			return false;
		}
		return true;

	}

	@Override
	public boolean respondentLogin(String userName, String passCode) {
		return respondentDao.respondentLogin(userName, passCode);

	}

	@Override
	public boolean choiceVerify(String choice) {
		while (!inputValidation.choiceValidation(choice)) {

			return false;
		}
		return true;

	}

	@Override
	public boolean addAnswers(String s, String answer1, String answer2, String answer3, String answer4) {
		resultBean.setSurvey(s);
		resultBean.setAnswer1(answer1);
		resultBean.setAnswer2(answer2);
		resultBean.setAnswer3(answer3);
		resultBean.setAnswer4(answer4);
		respondentSurvey.add(resultBean);
		return true;
	}

	@Override
	public boolean viewResponse() {
		
		return respondentDao.responseView();
	}

	@Override
	public boolean addRespondent(String userName,String password) {
		Respondent respondent = Factory.getRespondentInstance();
		respondent.setuserName(userName);
		respondent.setPassword(password);
		return dao.addRespondent(respondent);
		
	}

	

}