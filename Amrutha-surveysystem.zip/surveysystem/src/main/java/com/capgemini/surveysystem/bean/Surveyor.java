package com.capgemini.surveysystem.bean;

import java.io.Serializable;
/**
 * This is belongs to Surveyor login credentials using username and pasword;
 *
 */
public class Surveyor implements Serializable {
	private static final long serialVersionUID = 1L;

public Surveyor() {
	  
  }
	private String userName;
	private String password;
	private String emailId;
	private Long phoneNo;

	public String getuserName() {
		return userName;
	}

	public void setuserName(String userName) {
		this.userName = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public Long getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Surveyorbean [username=" + userName + ", password=" + password + ", emailId=" + emailId + ", phoneNo="
				+ phoneNo + "]";
	}


}
