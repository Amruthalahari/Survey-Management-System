package com.capgemini.surveysystem.bean;
import java.io.Serializable;
/**
 * This is belongs to Surveyor to add questions to the survey;
 *
 */
public class Survey  implements Serializable{
	private static final long serialVersionUID = 1L;
	public Survey() {
		
	}
	private String surveyName;
	 private String description;
	 private String question1,question2,question3,question4;
	 public String getSurveyName() {
		return surveyName;
	}

	public void setSurveyName(String surveyName) {
		this.surveyName = surveyName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	

	public String getQuestion1() {
		return question1;
	}

	public void setQuestion1(String question1) {
		this.question1 = question1;
	}

	public String getQuestion2() {
		return question2;
	}

	public void setQuestion2(String question2) {
		this.question2 = question2;
	}

	public String getQuestion3() {
		return question3;
	}

	public void setQuestion3(String question3) {
		this.question3 = question3;
	}

	public String getQuestion4() {
		return question4;
	}

	public void setQuestion4(String question4) {
		this.question4 = question4;
	}

	@Override
	public String toString() {
		return "Survey [surveyName=" + surveyName + ", description=" + description + ", question1=" + question1
				+ ", question2=" + question2 + ", question3=" + question3 + ", question4=" + question4 +"]";
	}
	
}
	