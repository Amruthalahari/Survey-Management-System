package com.capgemini.surveysystem.dao;

import com.capgemini.surveysystem.bean.Surveyor;
/**
 * This is Surveyor inteface and we declare methods
 *    methods to login to Surveyor to perform the operations in surveyor
 */
public interface SurveyorDao {
	public boolean deleteSurvey(String survey);
	public boolean updateSurvey(String survey);
	public boolean login(String surveyoruserName, String surveyorPassword);
	public boolean viewSurvey();
	public boolean addSurveyor(Surveyor surveyor);
	
}
