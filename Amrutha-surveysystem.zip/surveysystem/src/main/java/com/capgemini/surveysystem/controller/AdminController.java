package com.capgemini.surveysystem.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.controller.AdminController;
import com.capgemini.surveysystem.controller.RespondentController;
import com.capgemini.surveysystem.controller.SurveyController;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.service.AdminService;
/*
 * This is the Admin controller in which Admin can log in as Surveyor,Respondent and we can also addsurveyoe and
 addrespondent
 */
public class AdminController {
	static final Logger log = Logger.getLogger(AdminController.class);
	static AdminService adminService = Factory.getAdminServiceInstance();
	static Scanner sc = new Scanner(System.in);

	public static void adminlogin() {
		Properties properties= new Properties();
		try {
			properties.load(new FileInputStream("db.properties"));
		}catch(IOException e) {
			e.getMessage();
		}
		String adminUserName =properties.getProperty("adminUserName");
		String adminPassword =properties.getProperty("adminPassword");
		
		boolean login = adminService.Login(adminUserName, adminPassword);
		if (login == true) {
			log.info(" login successfull");
				Q: do {
					  log.info("Choose any one in following options");
					  log.info("1.Surveyor");
					  log.info("2.Respondent");
					  log.info("3.Add respondent");
					  log.info("4.Add surveyor");
					  log.info("5.Exit");
					  String choice=sc.nextLine();
					  while(!adminService.choiceValidation(choice)) {
						  log.info("please enter the valid Option");
							choice = sc.nextLine();
					  }
					  int admin = Integer.parseInt(choice);
					switch (admin) {
					case 1: 
						log.info("Login to Surveyor");
						SurveyController.suveryorlogin();
					break;
					case 2:
						log.info("Login to Respondent");
						RespondentController.respondentLogin();
					break;
					case 3:
						RespondentController.addRespondent();
						break;
					case 4:
						SurveyController.addSurveyor();
						break;
						
					case 5:
						break Q;
					}
				}
				while(true);
			}else {
				log.info("login failed");
			}
		}
		}

