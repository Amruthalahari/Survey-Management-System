package com.capgemini.surveysystem.dao;

import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.bean.Surveyor;
import com.capgemini.surveysystem.exceptions.SurveyorNotFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.repository.SurveyorRepository;

public class SurveyorDaoImpl implements SurveyorDao {
	Survey surveyBean = Factory.getSurveyInstance();
	int count = 0;

	@Override
	public boolean login(String surveyorUserName, String surveyorPassword) {
		if (surveyorUserName.contentEquals("surveyor") && surveyorPassword.equals("surveyor")) {
			return true;
		}
		return false;
	}

	@Override

	public boolean updateSurvey(String survey) {

		for (Survey surveyBean : SurveyRepository.surveyNames) {
			if (surveyBean.getSurveyName().equals(survey)) {
				count++;
				return true;
			}
		}
		if (count == 0)
			throw new SurveyorNotFoundException();
		return false;
	}

	@Override
	public boolean deleteSurvey(String survey) throws SurveyorNotFoundException {
		int count=0;
		for (Survey surveybean : SurveyRepository.surveyNames) {
			if (surveybean.getSurveyName().equals(survey)) {
				count++;
				SurveyRepository.surveyNames.remove(surveybean);
			}
		}
		if (count == 0) {
			throw new SurveyorNotFoundException();
		}else{
		return true;
		}

	}

	@Override
	public boolean viewSurvey() {
		if (SurveyRepository.surveyNames.isEmpty()) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public boolean addSurveyor(Surveyor surveyor) {
		SurveyorRepository.surveylist.add(surveyor);
		return false;
	}

}