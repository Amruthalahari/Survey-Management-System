package com.capgemini.surveysystem.bean;
import java.io.Serializable;
/**
 * This is belongs to Admin login credentials using username and password;
 *
 */
public class Admin implements Serializable {
	private static final long serialVersionUID = 1L;
	public Admin() {
		
	}
	private String userName;
	private  String password;
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Adminbean [userName=" + userName + ", password=" + password + "]";
	}
}
