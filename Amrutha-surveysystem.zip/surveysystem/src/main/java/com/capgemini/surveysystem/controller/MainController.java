package com.capgemini.surveysystem.controller;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.AdminRepository;
import com.capgemini.surveysystem.repository.RespondentRepository;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.repository.SurveyorRepository;
import com.capgemini.surveysystem.service.SurveyorService;
/*
 * This is the Main controller where the user chooses te options which he wants
 */
public class MainController {
	static final Logger log = Logger.getLogger(MainController.class);
	static Scanner sc = new Scanner(System.in);

	public static void main(String[] args) {
		 Factory.getInputValidationInstance();
		 Factory.getSurveyorDaoInstance();
		 Factory.getAdminInstance();
		 Factory.getRespondentDaoInstance();
		 Factory.getSurveyorInstance();
		 Factory.getAdminDaoInstance();
		Factory.getSurveyRepository();
		RespondentRepository respondentRepository = Factory.getRespondentRepository();
		AdminRepository adminRepository = Factory.getAdminRepository();
		SurveyorRepository surveyorRepository = Factory.getSurveyorRepository();
		SurveyorService surveyorService = Factory.getSurveyorServiceInstance();
		surveyorRepository.surveyor();
		SurveyRepository.survey();
		respondentRepository.respondent();
		adminRepository.admin();
		Properties properties = new Properties();
		try {
			properties.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			e.getMessage();
		}
		log.info("*****Welcome to Survey Management System*****");

		do {
			log.info("please tell us who are you");
			log.info("1.Admin");
			log.info("2.Surveyor");
			log.info("3.Respondent");
			log.info("4.Exit");
			log.info("select a choice (1-4)");
			String choice = sc.next();
		  surveyorService.choiceVerify(choice);
			while (!surveyorService.choiceVerify(choice)) {
				log.info("please enter valid choice");
				choice = sc.next();
			}
			int choice1 = Integer.parseInt(choice);

			switch (choice1) {

			case 1:
				AdminController.adminlogin();
				break;
			case 2:
				SurveyController.suveryorlogin();
				break;

			case 3:
				RespondentController.respondentLogin();
				break;
			case 4:
				log.info("Exit!!");

				break;
			default:
				log.info("Select valid choice");
				break;
			}
		} while (true);

	}
}
