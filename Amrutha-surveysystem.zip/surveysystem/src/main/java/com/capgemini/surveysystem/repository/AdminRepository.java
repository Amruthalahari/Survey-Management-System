package com.capgemini.surveysystem.repository;
import java.util.ArrayList;
import java.util.List;
import com.capgemini.surveysystem.bean.Admin;
import com.capgemini.surveysystem.factory.Factory;
/*
 * This AdminRepository consists of dummydata which is used to  login to the admin
 */
public class AdminRepository {
	public static ArrayList<Admin> adminlist = new ArrayList<Admin>();
	public List<Admin> admin(){
		Admin adminBean1 = Factory.getAdminInstance();
		adminBean1.setuserName("admin");
		adminBean1.setPassword("admin");
		adminlist.add(adminBean1);
		return adminlist;
		
		
	}
}
