package com.capgemini.surveysystem.controller;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ConcurrentModificationException;
import java.util.Properties;
import java.util.Scanner;
import org.apache.log4j.Logger;
import com.capgemini.surveysystem.bean.Survey;
import com.capgemini.surveysystem.exceptions.SurveyorNotFoundException;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.repository.SurveyRepository;
import com.capgemini.surveysystem.service.RespondentService;
import com.capgemini.surveysystem.service.SurveyorService;
import com.capgemini.surveysystem.validation.InputValidation;

/*
 * This is the Surveyor controller in which Surveyor can create,edit,delete and can view all the surveys
 */
public class SurveyController {
	static SurveyorService surveyorService = Factory.getSurveyorServiceInstance();
	static final Logger log = Logger.getLogger(SurveyController.class);
	static InputValidation inputValidations = Factory.getInputValidationInstance();
	static Survey surveybean = Factory.getSurveyInstance();
	static Scanner sc = new Scanner(System.in);
	static int count = 0;
	static RespondentService respondentService = Factory.getRespondentServiceInstance();

	public static void suveryorlogin() {
		Properties props = new Properties();
		try {
			props.load(new FileInputStream("db.properties"));
		} catch (IOException e) {
			e.getMessage();
		}
		String SurveyorUserName = props.getProperty("surveyorUserName");
		String SurveyorPassword = props.getProperty("surveyorPassword");

		boolean Login = surveyorService.Login(SurveyorUserName, SurveyorPassword);
		if (Login == true) {
			surveydetails();
		} else {
			log.info("login failed");
		}
	}

	public static boolean surveydetails() {
		Factory.getSurveyorInstance();
		m: do {
			log.info("1.Create survey");
			log.info("2.Edit survey");
			log.info("3.Delete survey");
			log.info("4.List all surveys");
			log.info("5.Exit");

			String choice = sc.next();
			while (!surveyorService.choiceVerify(choice)) {
				log.info("please enter valid choice");
				choice = sc.next();
			}
			int choice1 = Integer.parseInt(choice);

			switch (choice1) {

			case 1:
				log.info("Please enter survey name (a-z)");
				String survey = sc.next();
				while (!surveyorService.surveyVerify(survey)) {
					log.info("please enter valid survey name");
					survey = sc.next();
				}
				log.info(" Please enter survey description (a-z)");
				String description = sc.next();
				while (!surveyorService.descriptionVerify(description)) {
					log.info("please enter valid description");
					description = sc.next();
				}
				sc.nextLine();
				log.info("Please enter question1 (a-zA-Z) ");
				String q1 = sc.nextLine();
				while (!surveyorService.questionVerify(q1)) {
					log.info("please enter valid question");
					q1 = sc.nextLine();
				}

				log.info("Please enter question2 (a-zA-Z)");
				String q2 = sc.nextLine();
				while (!surveyorService.questionVerify(q2)) {
					log.info("please enter valid question");
					q2 = sc.nextLine();
				}

				log.info("Please enter question3 (a-zA-Z)");
				String q3 = sc.nextLine();
				while (!surveyorService.questionVerify(q3)) {
					log.info("please enter valid question");
					q3 = sc.nextLine();
				}

				log.info("Please enter question4 (a-zA-Z)");
				String q4 = sc.nextLine();
				while (!surveyorService.questionVerify(q4)) {
					log.info("please enter valid question");
					q4 = sc.nextLine();
				}
				log.info("Your survey is created");
				surveyorService.createSurvey(survey, description, q1, q2, q3, q4);

				break;

			case 2:
				sc.nextLine();
				log.info("Please Enter survey name (a-z)");
				String survey1 = sc.next();
				while (!surveyorService.surveyVerify(survey1)) {
					log.info("please enter valid survey name");
					survey1 = sc.next();
				}
				try {
					boolean a = surveyorService.update(survey1);
					if (a == true) {
						log.info("survey found");
					} else {
						throw new SurveyorNotFoundException();
					}
				} catch (SurveyorNotFoundException e) {
					log.info(e.getMessage());
					break;
				}

				for (Survey surveybean : SurveyRepository.surveyNames) {
					if (surveybean.getSurveyName().contentEquals(survey1)) {
						count++;
						log.info("Please Enter new survey name (a-z)");
						String survey2 = sc.next();
						while (!surveyorService.surveyVerify(survey2)) {
							log.info("please enter valid survey name");
							survey2 = sc.next();
						}
						log.info("Please Enter new survey description (a-z)");
						String description1 = sc.next();
						while (!surveyorService.descriptionVerify(description1)) {
							log.info("please enter valid description");
							description1 = sc.next();
						}

						log.info("Enter question1 with (a-zA-Z) ");
						String q11 = sc.nextLine();
						while (!surveyorService.questionVerify(q11)) {
							log.info("please enter valid question");
							q11 = sc.nextLine();
						}

						log.info("Enter question2 with (a-zA-Z)");
						String q22 = sc.nextLine();
						while (!surveyorService.questionVerify(q22)) {
							log.info("please enter valid question");
							q22 = sc.nextLine();
						}

						log.info("Enter question3 with (a-zA-Z)");
						String q33 = sc.nextLine();
						while (!surveyorService.questionVerify(q33)) {
							log.info("please enter valid question");
							q33 = sc.nextLine();
						}

						log.info("Enter question4 with (a-zA-Z)");
						String q44 = sc.nextLine();
						while (!surveyorService.questionVerify(q44)) {
							log.info("please enter valid question");
							q44 = sc.nextLine();
						}
						log.info("Your survey is edited");

						surveybean.setSurveyName(survey2);
						surveybean.setDescription(description1);
						surveybean.setQuestion1(q11);
						surveybean.setQuestion2(q22);
						surveybean.setQuestion3(q33);
						surveybean.setQuestion4(q44);
						
					}
				}
				break;
			case 3:
				sc.nextLine();
				log.info("enter survey name (a-z)");
				String survey3 = sc.next();
				while (!surveyorService.surveyVerify(survey3)) {
					log.info("please enter valid survey name");
					survey3 = sc.next();
				}
				try {
					boolean delete = surveyorService.checkSurvey(survey3);
					if (delete) {
						log.info("survey found and deleted");
					}
				} catch (SurveyorNotFoundException e) {
					log.info(e.getMessage());
					break;
				} catch (ConcurrentModificationException e) {
					log.info(e.getMessage());
					log.info("survey found and deleted");

				}

				break;
			case 4:
				log.info("Your surveys are:");
				boolean viewsurvey = surveyorService.surveyView();
				for (Survey surveybean : SurveyRepository.surveyNames) {
					if (viewsurvey == true) {
						log.info("survey is empty");
					} else {
						log.info(surveybean);
					}
				}
				break;
			case 5:
				break m;
			default:
				log.info("Select valid choice");
				break;
			}
		} while (true);
		return false;
	}

	public static void addSurveyor() {

		log.info("please enter the required credintials to create account");
		log.info(" Please enter new Respondent userName(a-z)");
		String userName = sc.next();
		while (!inputValidations.nameValidation(userName)) {
			log.info("please enter  the valid username");
			userName = sc.next();
		}

		log.info("Please enter new password (a-z)");
		String password = sc.next();
		while (!inputValidations.passwordValidation(password)) {
			log.info("please enter the  valid password");
			password = sc.next();
		}

		log.info("Please enter new email (abcd@gmail.com)");
		String gmail = sc.next();
		while (!inputValidations.emailValidation(gmail)) {
			log.info("please enter the  valid mailid");
			gmail = sc.next();
		}

		log.info("Please enter new mobileNumber (10 digits)");
		String number = sc.next();
		while (!inputValidations.mobileNoValidation(number)) {
			log.info("please enter the  valid number");
			number = sc.next();
		}
		long mobileNumber = Long.parseLong(number);

		log.info("Your response is added successfully\n");

		surveyorService.addSurveyor(userName, password, gmail, mobileNumber);

	}

}