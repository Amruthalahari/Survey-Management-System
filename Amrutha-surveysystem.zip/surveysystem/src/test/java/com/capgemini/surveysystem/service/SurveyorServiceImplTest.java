package com.capgemini.surveysystem.service;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.service.SurveyorService;

class SurveyorServiceImplTest {


	@Test
	@Tag("choiceVerify")
	void testchoiceVerify() {
		SurveyorService surveyorService=Factory.getSurveyorServiceInstance();
		assertEquals(true,surveyorService.choiceVerify ("3"));
	}
	@Test
	@Tag("descriptionVerify")
	void testdescriptionVerify() {
		SurveyorService surveyorService=Factory.getSurveyorServiceInstance();
		assertEquals(true,surveyorService.descriptionVerify ("lahari"));
	}
	
	@Test
	@Tag("SurveyVerify")
	void testSurveyVerify() {
		SurveyorService surveyorService=Factory.getSurveyorServiceInstance();
		assertEquals(true,surveyorService.surveyVerify("lahari"));
	}
	

	
	@Test
	@Tag("nameVerify")
	void testnameVerify() {
		SurveyorService surveyorService=Factory.getSurveyorServiceInstance();
		assertEquals(true,surveyorService.nameVerify("amrutha"));
	}

	
}
