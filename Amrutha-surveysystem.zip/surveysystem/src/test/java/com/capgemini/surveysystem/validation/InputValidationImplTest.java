package com.capgemini.surveysystem.validation;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.validation.InputValidation;

class InputValidationImplTest {

	InputValidation inputValidations=Factory.getInputValidationInstance();

	@Test
	void testNameValidation() {
		assertEquals(true, inputValidations.nameValidation("amrutha"));
	}

	@Test
	void testChoiceValidate() {
		assertEquals(true, inputValidations.choiceValidation("3"));
	}

	@Test
	void testEmailValidation() {
		assertEquals(true, inputValidations.emailValidation("Amrutha@123"));
	}

	@Test
	void testPasswordValidation() {
		assertEquals(true, inputValidations.passwordValidation("Amrutha#"));
	}

	@Test
	void testMobileNoValidation() {
		assertEquals(true, inputValidations.mobileNoValidation("9963914023"));
	}

	@Test
	void testSurveyValidation() {
		assertEquals(true, inputValidations.surveyValidation("lahari"));
	}

	@Test
	void testDescriptionValidation() {
		assertEquals(true, inputValidations.descriptionValidation("lahari"));
	}

	
	@Test
	void testMultipleanswerValidation() {
		assertEquals(true, inputValidations.multipleAnswerValidation("a"));
	}



}
