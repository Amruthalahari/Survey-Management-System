package com.capgemini.surveysystem.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.dao.RespondentDao;
import com.capgemini.surveysystem.factory.Factory;

class RespondentDaoImplTest {

	@Test
	@Tag("RespondentLogin")
	void testRespondentLogin() {
		RespondentDao respondentDAO=Factory.getRespondentDaoInstance();
		assertEquals(false,respondentDAO.respondentLogin("respondent","respondent"));
	}
	@Test
	@Tag("View")
	void testViewresponse() {
		RespondentDao respondentDAO=Factory.getRespondentDaoInstance();
	assertEquals(true,respondentDAO.responseView());
	}

}
