package com.capgemini.surveysystem.dao;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.dao.SurveyorDao;
import com.capgemini.surveysystem.factory.Factory;

class SurveyorDaoImplTest {

	@Test
	@Tag(" Login")
	void testSurveyorLogin() {
		SurveyorDao surveyorDAO = Factory.getSurveyorDaoInstance();
		assertEquals(true,surveyorDAO.login("surveyor", "surveyor"));
	}
	@Test
	@Tag("View")
	void testViewSurvey() {
		SurveyorDao surveyorDAO = Factory.getSurveyorDaoInstance();
	assertEquals(true,surveyorDAO.viewSurvey());
	}
}
