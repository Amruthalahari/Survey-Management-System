package com.capgemini.surveysystem.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.service.RespondentService;

class RespondentServiceImplTest {
	@Test
	@Tag("choiceVerify")
	void testchoiceVerify() {
		RespondentService respondentService=Factory.getRespondentServiceInstance();
		assertEquals(true,respondentService.choiceVerify ("3"));
	}
	@Test
	@Tag("userNameVerify")
	void testuserNameVerify() {
		RespondentService respondentService=Factory.getRespondentServiceInstance();
		assertEquals(false,respondentService.userNameVerify("Amrutha"));
	}
	@Test
	@Tag("passwordVerify")
	void testpasswordVerify() {
		RespondentService respondentService=Factory.getRespondentServiceInstance();
		assertEquals(true,respondentService.passwordVerify("Amrutha#"));
	}
	@Test
	@Tag("SurveyVerify")
	void testSurveyVerify() {
		RespondentService respondentService=Factory.getRespondentServiceInstance();
		assertEquals(true,respondentService.surveyVerify("lahari"));
	}
	
	@Test
	@Tag("PhoneNoVerify")
	void testPhoneNoVerify() {
		RespondentService respondentService=Factory.getRespondentServiceInstance();
		assertEquals(true,respondentService.phoneNoVerify("9963914023"));
	}

	
	@Test
	@Tag("View")
	void testViewresponse() {
		RespondentService respondentService=Factory.getRespondentServiceInstance();
	assertEquals(true,respondentService.viewResponse());
	}
	
}

