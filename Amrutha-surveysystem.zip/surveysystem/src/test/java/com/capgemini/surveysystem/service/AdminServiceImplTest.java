package com.capgemini.surveysystem.service;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

import com.capgemini.surveysystem.factory.Factory;
import com.capgemini.surveysystem.service.AdminService;

class AdminServiceImplTest {

	@Test
	@Tag("Login")
	void testadminLogin() {
		AdminService adminService=Factory.getAdminServiceInstance();
		assertEquals(true,adminService.Login("admin","admin"));
	}
	@Test
	@Tag("choiceValidation")
	void testchoiceValidation() {
		AdminService adminService=Factory.getAdminServiceInstance();
		assertEquals(true,adminService.choiceValidation ("3"));
	}
      
}

