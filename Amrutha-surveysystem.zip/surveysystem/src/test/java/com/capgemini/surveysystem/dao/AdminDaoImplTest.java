package com.capgemini.surveysystem.dao;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import com.capgemini.surveysystem.dao.AdminDao;
import com.capgemini.surveysystem.factory.Factory;

class AdminDaoImplTest {


	@Test
	@Tag("Login")
	void testadminLogin() {
		AdminDao adminDAO=Factory.getAdminDaoInstance();
		assertEquals(true,adminDAO.adminLogin("admin", "admin"));
	}


}
